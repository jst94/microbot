package net.runelite.client.plugins.microbot.jstplugins.jstscurrius.JstScurriusScript;

import javax.inject.Inject;
import net.runelite.client.ui.overlay.Overlay;
import net.runelite.client.ui.overlay.OverlayLayer;
import net.runelite.client.ui.overlay.OverlayPosition;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Color;

public class JstScurriusScriptOverlay extends Overlay {
    
    private final JstScurriusScriptPlugin plugin;

    @Inject
    public JstScurriusScriptOverlay(JstScurriusScriptPlugin plugin) {
        this.plugin = plugin;
        setPosition(OverlayPosition.TOP_LEFT);
        setLayer(OverlayLayer.ALWAYS_ON_TOP);
    }

    @Override
    public Dimension render(Graphics2D graphics) {
        State state = plugin.getState(); // Ensure correct type is used
        String text = String.format("Current State: %s", state.toString());

        graphics.setColor(Color.WHITE);
        graphics.drawString(text, 10, 20);

        return null;
    }
}
