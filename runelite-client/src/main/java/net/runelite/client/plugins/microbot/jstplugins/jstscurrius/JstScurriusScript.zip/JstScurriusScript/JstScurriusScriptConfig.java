package net.runelite.client.plugins.microbot.jstplugins.jstscurrius.JstScurriusScript;

import net.runelite.client.config.Config;
import net.runelite.client.config.ConfigGroup;
import net.runelite.client.config.ConfigItem;

@ConfigGroup("jstscurriusscript")
public interface JstScurriusScriptConfig extends Config {
    
    @ConfigItem(
        keyName = "scriptDelay",
        name = "Script Delay",
        description = "Delay between script actions in milliseconds",
        position = 0
    )
    default int getScriptDelay() {
        return 1000; // Default delay
    }

    @ConfigItem(
        keyName = "foodAmount",
        name = "Food Amount",
        description = "Amount of food to withdraw",
        position = 1
    )
    default int getFoodAmount() {
        return 10; // Default food amount
    }

    @ConfigItem(
        keyName = "prayerPotionAmount",
        name = "Prayer Potion Amount",
        description = "Amount of prayer potions to withdraw",
        position = 2
    )
    default int getPrayerPotionAmount() {
        return 5; // Default prayer potion amount
    }

    @ConfigItem(
        keyName = "minPrayerPoints",
        name = "Minimum Prayer Points",
        description = "Minimum prayer points to maintain",
        position = 3
    )
    default int getMinPrayerPoints() {
        return 20; // Default minimum prayer points
    }

    @ConfigItem(
        keyName = "minHealthPercent",
        name = "Minimum Health Percent",
        description = "Minimum health percentage to maintain",
        position = 4
    )
    default int getMinHealthPercent() {
        return 30; // Default minimum health percent
    }
}
