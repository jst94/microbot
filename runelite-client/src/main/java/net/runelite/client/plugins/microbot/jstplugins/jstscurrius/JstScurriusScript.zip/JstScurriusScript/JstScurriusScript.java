package net.runelite.client.plugins.microbot.jstplugins.jstscurrius.JstScurriusScript;

import com.google.inject.Inject;
import net.runelite.api.NPC;
import net.runelite.api.Skill;
import net.runelite.api.coords.WorldPoint;
import net.runelite.client.plugins.microbot.Microbot;
import net.runelite.client.plugins.microbot.Script;
import net.runelite.client.plugins.microbot.util.bank.Rs2Bank;
import net.runelite.client.plugins.microbot.util.gameobject.Rs2GameObject;
import net.runelite.client.plugins.microbot.util.grounditem.Rs2GroundItem;
import net.runelite.client.plugins.microbot.util.inventory.Rs2Inventory;
import net.runelite.client.plugins.microbot.util.npc.Rs2Npc;
import net.runelite.client.plugins.microbot.util.player.Rs2Player;
import net.runelite.client.plugins.microbot.util.prayer.Rs2Prayer;
import net.runelite.client.plugins.microbot.util.prayer.Rs2PrayerEnum;
import net.runelite.client.plugins.microbot.util.walker.Rs2Walker;
import java.util.concurrent.atomic.AtomicReference;
import net.runelite.api.ItemID; // Ensure FOOD and PRAYER_POTION are defined in ItemID

import java.util.Arrays;
import java.util.concurrent.TimeUnit;

public class JstScurriusScript extends Script {

    private static final int[] SCURRIUS_NPC_IDS = {12206, 12207}; // Example IDs, replace with actual

    @Inject
    private JstScurriusScriptConfig config;

    private final AtomicReference<State> state = new AtomicReference<>(State.BANKING);
    private NPC scurrius;
    private boolean isRunning = false;
    private long stateStartTime;
    private static final long STATE_TIMEOUT_MS = 30000; // 30 seconds timeout

    // Removed @Override annotations
    public void start() { 
        isRunning = true;
        state.set(State.BANKING);
        stateStartTime = System.currentTimeMillis(); // Initialize stateStartTime
    }

    public void stop() { 
        isRunning = false;
        state.set(State.BANKING);
    }

    public State getState() {
        return state.get();
    }

    @Override
    public boolean run() {
        Microbot.enableAutoRunOn = true;

        mainScheduledFuture = scheduledExecutorService.scheduleWithFixedDelay(() -> {
            try {
                if (!isRunning || !Microbot.isLoggedIn()) return;
                if (!super.run()) return;

                updateScurrius();
                handleStateTransition();
                executeCurrentState();

            } catch (Exception ex) {
                Microbot.log("Error: " + ex.getMessage());
            }
        }, 0, config.getScriptDelay(), TimeUnit.MILLISECONDS);
        return true;
    }

    private void updateScurrius() {
        scurrius = null;
        int retries = 3;
        while (retries > 0) {
            try {
                for (int npcId : SCURRIUS_NPC_IDS) {
                    scurrius = Rs2Npc.getNpc(npcId);
                    if (scurrius != null) return;
                }
                Microbot.sleep(600); // Replace with Thread.sleep
                retries--;
            } catch (Exception e) {
                Microbot.log("Failed to lookup Scurrius: " + e.getMessage());
                retries--;
            }
        }
        if (scurrius == null) {
            Microbot.log("Could not find Scurrius after retries");
        }
    }

    private void handleStateTransition() {
        boolean hasFood = !Rs2Inventory.getInventoryFood().isEmpty();

        boolean hasPrayer = Rs2Prayer.getPrayerPoints() > config.getMinPrayerPoints();
        boolean needsSupplies = !hasFood || !hasPrayer;
        boolean isInFightRoom = isInFightRoom();

        if (state.get() == State.FIGHTING && needsSupplies) {
            state.set(State.TELEPORT_AWAY);
        } else if (state.get() == State.BANKING && hasEnoughSupplies()) {
            state.set(State.WALK_TO_BOSS);
        } else if (state.get() == State.WALK_TO_BOSS && isInFightRoom) {
            state.set(scurrius != null ? State.FIGHTING : State.WAITING_FOR_BOSS);
        }

    }    private void executeCurrentState() {
        if (System.currentTimeMillis() - stateStartTime > STATE_TIMEOUT_MS) {
            Microbot.log("State " + state + " timed out, resetting to BANKING");
            state.set(State.BANKING);
            stateStartTime = System.currentTimeMillis();
            return;
        }

        switch (state.get()) {
            case BANKING:
                handleBanking();
                break;
            case TELEPORT_AWAY:
                handleTeleport();
                break;
            case WALK_TO_BOSS:
                Rs2Walker.walkTo(bossLocation);
                break;
            case FIGHTING:
                handleFighting();
                break;
            case WAITING_FOR_BOSS:
                // Just wait for boss to spawn
                break;
        }
    }

    private boolean isInFightRoom() {
        return Rs2Player.getLocalLocation().distanceTo(bossLocation) < 20; // Correct variable name
    }

    private boolean hasEnoughSupplies() {
        return !Rs2Inventory.getInventoryFood().isEmpty() && 
               Rs2Prayer.getPrayerPoints() > config.getMinPrayerPoints();
    }

    private void handleBanking() {
        if (!Rs2Bank.isOpen()) {
            Rs2Bank.openBank();
            return;
        }
        // Deposit all items except essential supplies
        Rs2Bank.depositAllExcept(Arrays.asList(ItemID.FOOD, ItemID.PRAYER_POTION1)); // Ensure PRAYER_POTION exists
        
        // Withdraw necessary supplies
        Rs2Bank.withdrawItem(ItemID.FOOD, config.getFoodAmount()); // Ensure getFoodAmount() exists
        Rs2Bank.withdrawItem(ItemID.PRAYER_POTION1, config.getPrayerPotionAmount()); // Ensure getPrayerPotionAmount() exists
        
        // Close the bank
        Rs2Bank.closeBank();
    }

    private void handleTeleport() {
        // Use teleport spell or item to teleport away
        if (Rs2Prayer.isTeleportAvailable()) { // Ensure isTeleportAvailable() exists
            Rs2Prayer.castTeleport(); // Ensure castTeleport() exists
        } else {
            Rs2Prayer.useTeleportItem(); // Ensure useTeleportItem() exists
        }
    }

    private void handleFighting() {
        if (scurrius == null) return;

        // Enable protect from melee prayer
        Rs2Prayer.togglePrayer(Rs2PrayerEnum.PROTECT_FROM_MELEE, true); // Ensure PROTECT_FROM_MELEE exists

        // Attack the boss if not already interacting
        if (!Rs2Player.getLocal().isInteracting()) {
            Rs2Npc.interact(scurrius, "Attack");
        }

        // Eat food if health is low
        if (Rs2Player.getLocal().getHealthPercent() < config.getMinHealthPercent()) {
            Rs2Inventory.eat(); // Ensure eat() exists
        }

        // Manage prayer points
        if (Rs2Prayer.getPrayerPoints() < config.getMinPrayerPoints()) { // Ensure getMinPrayerPoints() exists
            Rs2Inventory.withdrawPrayerPotions(); // Ensure withdrawPrayerPotions() exists
        }
    }

    private enum State { // Ensure State enum is correctly referenced
        BANKING,
        TELEPORT_AWAY,
        WALK_TO_BOSS,
        FIGHTING,
        WAITING_FOR_BOSS
    }

    private final WorldPoint bossLocation = new WorldPoint(3279, 9869, 0);
}
