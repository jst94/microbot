package net.runelite.client.plugins.microbot.jstplugins.jstscurrius.JstScurriusScript;

import javax.inject.Inject;
import net.runelite.client.plugins.Plugin;
import net.runelite.client.plugins.PluginDescriptor; // Correct import
import net.runelite.client.ui.overlay.OverlayManager; // Correct import
import net.runelite.client.plugins.microbot.Microbot; // Correct import

@PluginDescriptor(
    name = "JstScurrius Script",
    description = "Automates interactions with Scurris.",
    tags = {"microbot", "script", "automation"}
)
public class JstScurriusScriptPlugin extends Plugin {
    
    @Inject
    private JstScurriusScriptConfig config;
    
    @Inject
    private JstScurriusScript script;
    
    @Inject
    private JstScurriusScriptOverlay overlay;
    
    @Inject
    private OverlayManager overlayManager;

    @Override
    protected void startUp() { // Ensure method signature matches superclass
        overlayManager.add(overlay);
        script.start();
        Microbot.log("JstScurriusScriptPlugin started.");
    }

    @Override
    protected void shutDown() { // Ensure method signature matches superclass
        script.stop();
        overlayManager.remove(overlay);
        Microbot.log("JstScurriusScriptPlugin stopped.");
    }

    public State getState() {
        return script.getState(); // Ensure State enum is correctly referenced
    }
}
